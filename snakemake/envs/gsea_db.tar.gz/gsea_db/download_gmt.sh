wget -r --user anonymous --password email@gmail.com ftp://ftp.broadinstitute.org://pub/gsea/gene_sets
